
import { GoogleGenAI } from "@google/genai";
import { PERSONAL_INFO, EXPERIENCE_DATA, EDUCATION_DATA } from "../constants";

const getSystemInstruction = () => {
  // Use PERSONAL_INFO.slogan instead of non-existent tagline property
  return `You are an AI assistant for Shahadat Hossain Sujon. 
  His details:
  - Name: ${PERSONAL_INFO.name}
  - Role: ${PERSONAL_INFO.slogan}
  - Bio: ${PERSONAL_INFO.bio}
  - Location: ${PERSONAL_INFO.location}
  - Experience: ${JSON.stringify(EXPERIENCE_DATA)}
  - Education: ${JSON.stringify(EDUCATION_DATA)}
  
  Your goal is to answer questions from potential employers or blog readers about Shahadat. 
  Be professional, friendly, and concise. If you don't know an answer based on the provided info, 
  politely ask the user to contact Shahadat directly at ${PERSONAL_INFO.email}.`;
};

export const chatWithSujonAI = async (message: string) => {
  try {
    // Initialize GoogleGenAI with the required apiKey structure and direct process.env.API_KEY usage
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: message,
      config: {
        systemInstruction: getSystemInstruction(),
        temperature: 0.7,
      },
    });
    // Access the .text property of GenerateContentResponse directly as it is a getter
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm sorry, I'm having a bit of trouble connecting to my brain right now. Please try again or contact Shahadat directly!";
  }
};
