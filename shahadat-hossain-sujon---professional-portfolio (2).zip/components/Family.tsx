
import React from 'react';
import { FAMILY_INFO } from '../constants';

const Family: React.FC = () => {
  return (
    <section id="family" className="py-24 bg-slate-50 relative overflow-hidden">
      {/* Subtle decorative background elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-blue-100 rounded-full blur-[100px] opacity-40 -ml-32 -mt-32"></div>
      <div className="absolute bottom-0 right-0 w-64 h-64 bg-indigo-100 rounded-full blur-[100px] opacity-40 -mr-32 -mb-32"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">My Roots & Family</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-slate-900 mb-4">Guided by Love and Values</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {FAMILY_INFO.members.map((member, idx) => (
            <div 
              key={idx} 
              className="bg-white p-8 md:p-10 rounded-[2.5rem] shadow-sm border border-slate-100 hover:shadow-xl hover:border-blue-200 transition-all duration-500 group"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6 mb-6">
                <div className="w-16 h-16 bg-blue-50 text-blue-900 rounded-2xl flex items-center justify-center text-3xl group-hover:scale-110 transition-transform duration-500 shadow-sm border border-blue-100">
                  {member.icon}
                </div>
                <div>
                  <h4 className="text-2xl font-bold text-slate-900 group-hover:text-blue-900 transition-colors">{member.name}</h4>
                  <div className="flex flex-wrap items-center gap-x-2">
                    <span className="text-blue-600 font-bold uppercase text-[10px] tracking-widest">{member.relation}</span>
                    <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                    <span className="text-slate-500 font-medium text-sm">{member.role}</span>
                  </div>
                </div>
              </div>
              <p className="text-slate-600 leading-relaxed text-base">
                {member.description}
              </p>
              
              {/* Animated bottom accent */}
              <div className="w-12 h-1 bg-blue-900 mt-8 rounded-full origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
            </div>
          ))}
        </div>

        <div className="mt-20 p-12 bg-blue-900 rounded-[3rem] text-center text-white shadow-2xl shadow-blue-900/20 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-800 to-blue-950 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
          <div className="relative z-10">
            <div className="text-2xl md:text-3xl font-serif leading-relaxed italic text-blue-50">
              নীরব প্রকৃতির কোলে একলা আমি বসি,<br />
              পাতার ফাঁকে আলো এসে মনটাকে ছুঁই।<br />
              ভিড় নয়, নীরবতাই আমার আশ্রয়,<br />
              একাকিত্বেই খুঁজি নিজের সত্য পরিচয়।
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Family;
