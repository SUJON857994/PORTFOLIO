
import React from 'react';
import { PERSONAL_INFO, INTERESTS } from '../constants';

const IdentityStats: React.FC = () => {
  return (
    <section id="identity" className="py-24 bg-white scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Identity/Profile Section */}
          <div className="bg-slate-50 p-10 md:p-12 rounded-[3rem] border border-slate-100 shadow-sm">
            <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">Personal Identity</h2>
            <h3 className="text-4xl font-serif text-slate-900 mb-8">Who I Am</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
              {[
                { label: 'Height', value: PERSONAL_INFO.identity.height, icon: '📏' },
                { label: 'Weight', value: PERSONAL_INFO.identity.weight, icon: '⚖️' },
                { label: 'Eye Color', value: PERSONAL_INFO.identity.eyeColor, icon: '👁️' },
                { label: 'Hair Color', value: PERSONAL_INFO.identity.hairColor, icon: '💇' },
                { label: 'Fav Color', value: PERSONAL_INFO.identity.favColor, icon: '🎨' },
                { label: 'Blood Group', value: PERSONAL_INFO.identity.bloodGroup, icon: '🩸' },
              ].map((stat) => (
                <div key={stat.label} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-50 hover:border-blue-200 transition-colors">
                  <span className="text-2xl mb-2 block">{stat.icon}</span>
                  <p className="text-xs uppercase font-bold text-slate-400 tracking-wider mb-1">{stat.label}</p>
                  <p className="text-lg font-bold text-slate-900">{stat.value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Interests Section */}
          <div>
            <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">Lifestyle</h2>
            <h3 className="text-4xl font-serif text-slate-900 mb-8">What I Like</h3>
            <p className="text-slate-600 mb-10 leading-relaxed text-lg">
              Beyond my professional life, I find joy in the simple things. Whether it's exploring the rich literature of Bengal or catching a sunset in Noakhali, these are the things that fuel my creativity.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {INTERESTS.map((item) => (
                <div key={item.name} className="flex items-center space-x-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-blue-900 hover:text-white group transition-all cursor-default">
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-xl shadow-sm group-hover:scale-110 transition-transform">
                    {item.icon}
                  </div>
                  <span className="font-bold text-slate-800 group-hover:text-white transition-colors">{item.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IdentityStats;
