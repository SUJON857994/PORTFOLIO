
import React from 'react';
import { PERSONAL_INFO } from '../constants';

const Contact: React.FC = () => {
  // Extract digits for WhatsApp links
  const waNumberBD = PERSONAL_INFO.phone.replace(/\D/g, '');
  const waNumberJP = PERSONAL_INFO.phoneJapan?.replace(/\D/g, '') || '';

  return (
    <section id="contact" className="py-24 bg-slate-50">
      <div className="max-w-5xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">Connect</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-slate-900 mb-8 leading-tight">Let's Stay in Touch</h3>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Whether you're looking for financial advice, a quick learner for your team, or just want to discuss literature, I'm always open to meaningful conversations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {/* Email Card */}
          <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col items-center text-center group hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1">
            <div className="w-16 h-16 bg-blue-50 text-blue-900 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-900 group-hover:text-white transition-all duration-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>
            <p className="text-xs uppercase text-slate-400 font-bold tracking-widest mb-2">Email Me</p>
            <a href={`mailto:${PERSONAL_INFO.email}`} className="text-lg font-bold text-slate-900 hover:text-blue-900 transition-colors break-all">
              {PERSONAL_INFO.email}
            </a>
          </div>

          {/* WhatsApp Card */}
          <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col items-center text-center group hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1">
            <div className="w-16 h-16 bg-blue-50 text-blue-900 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-900 group-hover:text-white transition-all duration-500">
              <svg className="h-8 w-8" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
            </div>
            <p className="text-xs uppercase text-slate-400 font-bold tracking-widest mb-2">WhatsApp Me</p>
            <div className="flex flex-col space-y-2">
              <a href={`https://wa.me/${waNumberBD}`} target="_blank" rel="noopener noreferrer" className="text-lg font-bold text-slate-900 hover:text-blue-900 transition-colors flex items-center justify-center space-x-2">
                <span className="text-sm px-1.5 py-0.5 bg-slate-100 rounded text-slate-500 uppercase font-black text-[9px]">BD</span>
                <span>{PERSONAL_INFO.phone}</span>
              </a>
              <a href={`https://wa.me/${waNumberJP}`} target="_blank" rel="noopener noreferrer" className="text-lg font-bold text-slate-900 hover:text-blue-900 transition-colors flex items-center justify-center space-x-2">
                <span className="text-sm px-1.5 py-0.5 bg-slate-100 rounded text-slate-500 uppercase font-black text-[9px]">JP</span>
                <span>{PERSONAL_INFO.phoneJapan}</span>
              </a>
            </div>
          </div>

          {/* Skype Card */}
          <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col items-center text-center group hover:shadow-xl transition-all duration-500 transform hover:-translate-y-1">
            <div className="w-16 h-16 bg-blue-50 text-blue-900 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-900 group-hover:text-white transition-all duration-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
              </svg>
            </div>
            <p className="text-xs uppercase text-slate-400 font-bold tracking-widest mb-2">Skype</p>
            <a href={PERSONAL_INFO.skype} target="_blank" rel="noopener noreferrer" className="text-lg font-bold text-slate-900 hover:text-blue-900 transition-colors">
              Live Chat
            </a>
          </div>
        </div>

        {/* Social Buttons */}
        <div className="flex flex-wrap justify-center gap-6">
           {[
             { name: 'Facebook', url: PERSONAL_INFO.socials.facebook, color: 'hover:bg-[#1877f2]', label: 'Facebook' },
             { name: 'Instagram', url: PERSONAL_INFO.socials.instagram, color: 'hover:bg-[#e4405f]', label: 'Instagram' },
             { name: 'LitJoin Blog', url: PERSONAL_INFO.socials.blog, color: 'hover:bg-blue-600', label: 'My Blog' }
           ].map((social) => (
             <a 
               key={social.name}
               href={social.url}
               target="_blank"
               rel="noopener noreferrer"
               className={`px-10 py-4 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center font-bold text-slate-600 transition-all ${social.color} hover:text-white hover:-translate-y-1 active:scale-95`}
             >
               {social.label}
             </a>
           ))}
        </div>
      </div>
    </section>
  );
};

export default Contact;
