
import React from 'react';
import { EXPERIENCE_DATA } from '../constants';

const Experience: React.FC = () => {
  return (
    <section id="experience" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">Journey</h2>
            <h3 className="text-4xl font-serif text-slate-900 leading-tight">Professional Path & Community Service</h3>
          </div>
          <p className="text-slate-500 text-lg max-w-sm">Combining professional financial rigor with a heart for the community.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {EXPERIENCE_DATA.map((exp, idx) => (
            <div key={idx} className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl transition-all group">
              <div className="flex justify-between items-start mb-8">
                <div>
                  <span className="text-sm font-bold text-blue-600 mb-2 block">{exp.period}</span>
                  <h4 className="text-2xl font-bold text-slate-900 group-hover:text-blue-900 transition-colors">{exp.role}</h4>
                  <p className="text-slate-500 text-lg">{exp.company}</p>
                </div>
                <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-900">
                   {exp.role.includes("Volunteer") ? (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                   ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                   )}
                </div>
              </div>
              <ul className="space-y-4">
                {exp.highlights.map((item, i) => (
                  <li key={i} className="flex items-start space-x-3 text-slate-600">
                    <span className="mt-1.5 w-1.5 h-1.5 bg-blue-600 rounded-full flex-shrink-0"></span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
