
import React from 'react';
import { PERSONAL_INFO } from '../constants';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-white relative">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">About Me</h2>
        <h3 className="text-4xl md:text-5xl font-serif text-slate-900 mb-8">Bridging Finance and Creativity</h3>
        <p className="text-xl text-slate-600 leading-relaxed italic mb-12">
          "{PERSONAL_INFO.bio}"
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
          <div className="p-8 bg-slate-50 rounded-2xl border border-slate-100 hover:border-blue-200 transition-all group">
            <div className="w-12 h-12 bg-blue-900 text-white rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
               </svg>
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-2">Quick Learner</h4>
            <p className="text-sm text-slate-500">Adaptable to dynamic environments and always eager to acquire new professional skills.</p>
          </div>
          
          <div className="p-8 bg-slate-50 rounded-2xl border border-slate-100 hover:border-blue-200 transition-all group">
            <div className="w-12 h-12 bg-blue-900 text-white rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
               </svg>
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-2">Creative Blogger</h4>
            <p className="text-sm text-slate-500">Founder of LitJoin, where literature meets modern perspectives through insightful blogging.</p>
          </div>

          <div className="p-8 bg-slate-50 rounded-2xl border border-slate-100 hover:border-blue-200 transition-all group">
            <div className="w-12 h-12 bg-blue-900 text-white rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
               </svg>
            </div>
            <h4 className="text-lg font-bold text-slate-900 mb-2">Community Focused</h4>
            <p className="text-sm text-slate-500">Dedicated blood donor volunteer since 2018, believing in the power of social contribution.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
