
import React from 'react';
import { PERSONAL_INFO } from '../constants';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden scroll-mt-20">
      {/* Background Image Container */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&q=80&w=1600" 
          alt="Abstract Painting Background" 
          className="w-full h-full object-cover"
          onError={(e) => {
            console.error("Hero background image failed to load");
          }}
        />
        {/* Lighter overlays to ensure text readability */}
        <div className="absolute inset-0 bg-white/40 md:bg-white/30 backdrop-blur-[1px]"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/60 to-transparent"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
        <div className="space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="inline-block px-4 py-1.5 bg-blue-900 text-white rounded-full text-sm font-bold tracking-wide shadow-lg shadow-blue-900/20">
              WELCOME TO MY PERSONAL STORY
            </div>
            <div className="inline-flex items-center space-x-2 px-4 py-1.5 bg-white/90 backdrop-blur text-slate-700 rounded-full text-sm font-semibold shadow-sm border border-white transition-all hover:shadow-md hover:border-blue-200 cursor-default group">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-600 group-hover:scale-110 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <span className="text-slate-600">Currently living in <span className="font-bold text-blue-900">Kyoto, Japan</span></span>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-serif text-slate-900 leading-tight">
            Hi, I'm <br />
            <span className="text-blue-900">Shahadat Hossain Sujon</span>
          </h1>
          <p className="text-2xl md:text-3xl font-serif text-blue-800 italic leading-relaxed max-w-lg">
            "{PERSONAL_INFO.slogan}"
          </p>
          <div className="flex flex-wrap gap-4 pt-4">
            <a 
              href="#now" 
              className="px-8 py-4 bg-blue-900 text-white rounded-xl font-bold hover:bg-blue-800 transition-all transform hover:-translate-y-1 active:scale-95 shadow-xl shadow-blue-900/30 text-center"
            >
              What I'm Doing Now
            </a>
            <a 
              href="#experience" 
              className="px-8 py-4 bg-white text-blue-900 border border-blue-100 rounded-xl font-bold hover:bg-slate-50 transition-all transform hover:-translate-y-1 active:scale-95 shadow-sm flex items-center justify-center space-x-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <span>View My CV</span>
            </a>
          </div>
        </div>

        <div className="relative group perspective-1000">
          <div className="absolute inset-0 bg-blue-900 rounded-3xl rotate-3 group-hover:rotate-6 transition-transform duration-500 shadow-2xl opacity-20"></div>
          <img 
            src="https://images.unsplash.com/photo-1541963463532-d68292c34b19?auto=format&fit=crop&q=80&w=800" 
            alt="Abstract Artistic Texture" 
            className="relative z-10 w-full aspect-[4/5] object-cover rounded-3xl shadow-2xl transition-all duration-500 group-hover:-translate-x-2 group-hover:-translate-y-2 group-hover:shadow-blue-900/40"
          />
          <div className="absolute -bottom-6 -right-6 z-20 bg-white/95 backdrop-blur-sm p-6 rounded-2xl shadow-xl hidden md:block border border-slate-100 transform transition-transform group-hover:scale-105">
             <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-900">
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                   </svg>
                </div>
                <div>
                   <p className="font-bold text-slate-900 text-sm">Shahadat Hossain</p>
                   <p className="text-slate-500 text-xs text-nowrap">Financial Professional</p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
