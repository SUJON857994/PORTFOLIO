
import React, { useState } from 'react';
import { GALLERY_IMAGES } from '../constants';

const Gallery: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const openLightbox = (index: number) => {
    setSelectedImage(index);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <section id="gallery" className="py-24 bg-slate-50 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">My Gallery</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-slate-900">Life in Frames</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {GALLERY_IMAGES.map((img, idx) => (
            <div 
              key={idx} 
              onClick={() => openLightbox(idx)}
              className="group relative overflow-hidden rounded-3xl bg-slate-200 aspect-[4/5] min-h-[400px] shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer active:scale-[0.98]"
            >
              <img 
                src={img.url} 
                alt={img.caption} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                onError={(e) => {
                  console.error(`Failed to load gallery image: ${img.url}`);
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/90 via-blue-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                <p className="text-white font-bold text-xl translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  {img.caption}
                </p>
                <div className="w-10 h-1 bg-white mt-4 rounded-full origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-700"></div>
                <div className="mt-4 text-white/60 text-xs font-bold uppercase tracking-widest flex items-center space-x-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                  <span>Click to View Full Size</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedImage !== null && (
        <div 
          className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/95 backdrop-blur-md p-4 md:p-10 animate-in fade-in duration-300"
          onClick={closeLightbox}
        >
          <button 
            className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors p-2 z-[210] bg-white/10 rounded-full"
            onClick={closeLightbox}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div 
            className="relative max-w-5xl w-full h-full flex flex-col items-center justify-center"
            onClick={(e) => e.stopPropagation()}
          >
            <img 
              src={GALLERY_IMAGES[selectedImage].url} 
              alt={GALLERY_IMAGES[selectedImage].caption}
              className="max-w-full max-h-[80vh] object-contain rounded-xl shadow-2xl animate-in zoom-in-95 duration-500 border border-white/10"
            />
            <div className="mt-8 text-center bg-black/40 backdrop-blur-md p-6 rounded-2xl border border-white/5">
              <h4 className="text-2xl font-serif text-white mb-2">{GALLERY_IMAGES[selectedImage].caption}</h4>
              <p className="text-white/40 text-sm uppercase tracking-[0.2em]">Image {selectedImage + 1} of {GALLERY_IMAGES.length}</p>
            </div>
          </div>
          
          {/* Navigation Controls */}
          <button 
            className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 hover:text-white transition-all p-4 hidden md:block hover:bg-white/5 rounded-full"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedImage((prev) => (prev! === 0 ? GALLERY_IMAGES.length - 1 : prev! - 1));
            }}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button 
            className="absolute right-4 top-1/2 -translate-y-1/2 text-white/30 hover:text-white transition-all p-4 hidden md:block hover:bg-white/5 rounded-full"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedImage((prev) => (prev! === GALLERY_IMAGES.length - 1 ? 0 : prev! + 1));
            }}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      )}
    </section>
  );
};

export default Gallery;
