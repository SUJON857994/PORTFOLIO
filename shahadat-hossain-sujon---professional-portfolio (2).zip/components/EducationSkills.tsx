
import React from 'react';
import { EDUCATION_DATA, SKILLS } from '../constants';

const EducationSkills: React.FC = () => {
  return (
    <section id="education" className="py-24 bg-white scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Education Column */}
          <div className="order-2 lg:order-1">
            <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">Academic Background</h2>
            <h3 className="text-4xl font-serif text-slate-900 mb-12">Education Journey</h3>
            
            <div className="space-y-8">
              {EDUCATION_DATA.map((edu, idx) => (
                <div key={idx} className="relative pl-8 border-l-2 border-slate-100 pb-8 last:pb-0">
                  <div className={`absolute -left-[9px] top-0 w-4 h-4 rounded-full ${idx === 0 ? 'bg-blue-600 animate-pulse' : 'bg-blue-900'} ring-4 ring-blue-50`}></div>
                  <div className={`p-6 rounded-2xl transition-all hover:translate-x-1 group ${idx === 0 ? 'bg-blue-50 border border-blue-100 shadow-sm' : 'bg-slate-50'}`}>
                    <div className="flex justify-between items-start mb-1">
                      <span className={`text-xs font-bold uppercase tracking-widest block ${idx === 0 ? 'text-blue-700' : 'text-blue-600'}`}>{edu.year}</span>
                      {idx === 0 && <span className="bg-blue-900 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter">Current Pursuit</span>}
                    </div>
                    <h4 className="text-xl font-bold text-slate-900 group-hover:text-blue-900 transition-colors">{edu.degree}</h4>
                    <p className="text-slate-600 font-medium mb-2">{edu.institution}</p>
                    <p className="text-sm text-slate-500 leading-relaxed">
                      {edu.description.includes('https://') ? (
                        <>
                          {edu.description.split('https://')[0]}
                          <a 
                            href={`https://${edu.description.split('https://')[1]}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-700 font-bold hover:underline"
                          >
                            Visit Website
                          </a>
                        </>
                      ) : (
                        edu.description
                      )}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Skills Column */}
          <div className="order-1 lg:order-2">
            <h2 className="text-sm font-bold text-blue-600 tracking-[0.3em] uppercase mb-4">Core Competencies</h2>
            <h3 className="text-4xl font-serif text-slate-900 mb-12">Expertise & Proficiency</h3>
            
            <div className="space-y-8">
              {SKILLS.map((skill, idx) => (
                <div key={idx} className="group">
                  <div className="flex justify-between items-end mb-2">
                    <span className="font-bold text-slate-900 group-hover:text-blue-900 transition-colors">{skill.name}</span>
                    <span className="text-sm text-blue-600 font-bold">{skill.level}%</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-blue-900 rounded-full transition-all duration-1000 group-hover:bg-blue-600" 
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12">
              <h4 className="text-xs uppercase text-slate-400 font-bold tracking-[0.2em] mb-4">Additional Skills</h4>
              <div className="flex flex-wrap gap-3">
                {['Bengali (Native)', 'English (B2)', 'Internet Services', 'Skype & Zoom', 'Google Docs', 'Problem Solving', 'Travel Tech'].map((s) => (
                  <span key={s} className="px-4 py-2 bg-blue-50 text-blue-700 rounded-lg text-xs font-bold uppercase tracking-wider border border-blue-100 hover:bg-blue-900 hover:text-white transition-all cursor-default">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationSkills;
