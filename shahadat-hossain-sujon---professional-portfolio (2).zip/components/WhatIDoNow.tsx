
import React from 'react';
import { CURRENT_FOCUS } from '../constants';

const WhatIDoNow: React.FC = () => {
  return (
    <section id="now" className="py-24 bg-blue-900 text-white scroll-mt-20 overflow-hidden relative">
      {/* Decorative background shape */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-800 rounded-full blur-[100px] -mr-48 -mt-48 opacity-50"></div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="max-w-3xl mb-16">
          <h2 className="text-sm font-bold text-blue-300 tracking-[0.3em] uppercase mb-4">Current Journey</h2>
          <h3 className="text-4xl md:text-5xl font-serif mb-6 leading-tight">What I am doing now</h3>
          <p className="text-blue-100 text-lg leading-relaxed opacity-80">
            Life is a continuous process of growth. Here is a snapshot of my current professional, academic, and creative focus areas.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {CURRENT_FOCUS.map((focus, idx) => (
            <div key={idx} className="bg-white/10 backdrop-blur-md p-10 rounded-[2.5rem] border border-white/10 hover:bg-white/15 transition-all group">
              <div className="text-4xl mb-6 transform group-hover:scale-110 transition-transform duration-300 origin-left">
                {focus.icon}
              </div>
              <h4 className="text-2xl font-bold mb-4">{focus.title}</h4>
              <p className="text-blue-100/70 leading-relaxed">
                {focus.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhatIDoNow;
