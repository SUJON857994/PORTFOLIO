
import React from 'react';
import { RECENT_POSTS, PERSONAL_INFO } from '../constants';

const BlogSection: React.FC = () => {
  return (
    <section id="blog" className="py-24 bg-slate-900 text-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
         <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500 rounded-full blur-[120px]"></div>
         <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-500 rounded-full blur-[120px]"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {RECENT_POSTS.map((post, idx) => (
            <div key={idx} className="bg-white/5 rounded-3xl overflow-hidden border border-white/10 hover:border-blue-500/50 transition-all group flex flex-col h-full">
              <div className="relative overflow-hidden aspect-video">
                <img 
                  src={post.imageUrl} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-blue-600/80 backdrop-blur-md rounded-full text-xs font-bold">LITERATURE</span>
                </div>
              </div>
              <div className="p-8 flex flex-col flex-grow">
                <span className="text-blue-400 text-xs font-bold uppercase tracking-widest mb-3">{post.date}</span>
                <h4 className="text-xl font-bold mb-4 group-hover:text-blue-400 transition-colors leading-tight">
                  {post.title}
                </h4>
                <p className="text-slate-400 text-sm mb-8 leading-relaxed flex-grow">
                  {post.excerpt}
                </p>
                <a 
                  href={post.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 text-blue-400 font-bold hover:text-white transition-colors"
                >
                  <span>Read Full Post</span>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a 
            href={PERSONAL_INFO.socials.blog} 
            target="_blank" 
            rel="noopener noreferrer"
            className="px-10 py-5 bg-white text-slate-900 rounded-full font-bold hover:bg-blue-400 hover:text-white transition-all transform hover:-translate-y-1 inline-flex items-center space-x-3"
          >
            <span>Explore All Posts on LitJoin</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default BlogSection;
