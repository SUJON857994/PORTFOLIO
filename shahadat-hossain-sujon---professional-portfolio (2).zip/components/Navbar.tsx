
import React, { useState, useEffect } from 'react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Experience', href: '#experience' },
    { name: 'Education', href: '#education' },
    { name: 'Blog', href: '#blog' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled || isMobileMenuOpen ? 'bg-white/95 backdrop-blur-md shadow-md py-3' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <a href="#home" className="text-2xl font-serif font-bold text-blue-900 tracking-tight hover:scale-105 transition-transform">Sujon.</a>
        
        {/* Desktop Menu */}
        <div className="hidden lg:flex space-x-7 items-center">
          {menuItems.map((item) => (
            <a 
              key={item.name} 
              href={item.href}
              className="text-[13px] font-bold text-slate-600 hover:text-blue-900 transition-colors uppercase tracking-[0.1em]"
            >
              {item.name}
            </a>
          ))}
          <a 
            href="#contact" 
            className="ml-4 px-6 py-2.5 bg-blue-900 text-white rounded-full text-sm font-bold hover:bg-blue-800 transition-all shadow-lg hover:shadow-blue-900/30 active:scale-95"
          >
            Say Hello
          </a>
        </div>
        
        {/* Mobile menu trigger */}
        <button 
          className="lg:hidden text-blue-900 p-2 focus:outline-none hover:bg-slate-100 rounded-lg transition-colors"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle Menu"
        >
          {isMobileMenuOpen ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
            </svg>
          )}
        </button>
      </div>

      {/* Mobile Menu Content */}
      <div className={`lg:hidden absolute top-full left-0 w-full bg-white border-t border-slate-100 shadow-2xl transition-all duration-300 overflow-hidden ${isMobileMenuOpen ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0 pointer-events-none'}`}>
        <div className="flex flex-col p-8 space-y-5 bg-white">
          {menuItems.map((item) => (
            <a 
              key={item.name} 
              href={item.href}
              onClick={() => setIsMobileMenuOpen(false)}
              className="text-xl font-bold text-slate-800 hover:text-blue-900 transition-colors border-b border-slate-50 pb-3"
            >
              {item.name}
            </a>
          ))}
          <a 
            href="#contact" 
            onClick={() => setIsMobileMenuOpen(false)}
            className="w-full text-center px-6 py-4 bg-blue-900 text-white rounded-2xl text-lg font-bold hover:bg-blue-800 transition-all shadow-xl active:scale-95"
          >
            Connect With Me
          </a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
